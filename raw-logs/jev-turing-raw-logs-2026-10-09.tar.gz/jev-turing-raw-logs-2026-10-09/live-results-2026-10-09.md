# Live results, 2026-10-09

Model: `typesafe-ai/jev` via Vercel AI Gateway `/v1/evaluate`, paid credit.
Code: this repository (see its README "Live results").
Rules for every call: one Boolean question; inputs sent as `A=true; B=false`-style
state; the answer table never sent; P(true) >= 0.5 means true; no voting, no retries,
stop on the first failed call. Each run directory below has the raw per-call ledger.

## Results

| Run directory (`experiments/runs/`) | What | Calls | Result | Cost (gateway) |
|---|---|---:|---|---:|
| `live-nand-probe-20261008c` | NAND format check | 4 | 4/4 | $0.00006 |
| `live-nand-100-20261009` | NAND, 25 per input row | 100 | 100/100 (95% CI 96.3-100%) | $0.00138 |
| `live-xor-20261009` | XOR from 4 chained NANDs, 25 per row | 400 | 100/100 outputs, 0/400 wrong gates | $0.00551 |
| `live-latch-20261009` | SR latch demo + 10 trials x 5 holds | 180 | 0 write, 0 hold, 0 transient losses | $0.00248 |
| `live-r110-table-20261009` | Rule 110 rule, v1 wording | 39 | **Fail**: stopped by HTTP 429 at call 39; row 100 wrong 6/6 | ~$0.0005 |
| `live-r110-table-v2-20261009` | Rule 110 rule, v2 wording | 80 | 80/80 | $0.00131 |
| `live-r110-run-20261009` | Rule 110 from one cell, 20 steps | 385 | 0 wrong updates, 0 divergent cells | $0.00631 |
| `live-nand-4000-20261009` | NAND, 1,000 per input row | 4,000 | 4,000/4,000 (95% CI 99.90-100%) | $0.05510 |
| `live-r110-ether-20261009` | Rule 110, ether background, 64 steps | 4,771 | 0 wrong updates, 0 divergent cells | $0.07815 |
| `live-r110-ether-200-20261009` | Rule 110, ether background, 200 steps, 6 parallel calls per step | 26,340 | 0 wrong updates, 0 divergent cells (224 cells wide at the end) | $0.43145 |

| `live-latch-1000-20261009` | SR latch, 1,000 write trials x 5 holds | 15,030 | 1,000/1,000 kept the bit at every hold | $0.20705 |

Total spent: about 79 cents, out of $10 of credit. About 51,500 graded calls, 0 wrong.
The 200-step run: no busy-host retries, all answered by `typesafe-ai`, median latency
243 ms, 95th percentile 315 ms, about 25 minutes wall-clock.
Busy-host retries: 0. Hosts: `typesafe-ai` nearly all, `digitalocean` 31 calls in the two
large runs (all correct). Median latency about 250 ms, 95th percentile about 330 ms.

## What we learned

1. **Jev is a clean gate when the rule is stated.** NAND answers sat at P(true)
   0.98-0.99 or 0.02, far from the 0.5 line. Outputs fed straight into the next
   call with no cleanup (XOR, latch, Rule 110).
2. **Jev does not know "rule 110" by name.** With the rule only named, P(true)
   hovered at 0.42-0.77 on every row and neighbourhood `100` was wrong every time.
   Stating the rule in one sentence ("on exactly when C or R is on, unless all three
   are on") fixed it: P(true) >= 0.97 or <= 0.09. This is fair play: NAND is also
   given as a sentence. The 8-row table is still never sent.
3. **Host capacity matters.** Pinning requests to the `typesafe-ai` host returned
   HTTP 429 "at capacity". The default now lets the gateway choose a host for the
   same model and logs the host per call (`digitalocean` answered 4 of ~1,150 calls,
   all correct).
4. **No error seen yet.** Zero errors in 4,000 NAND calls bounds NAND's per-call error
   rate below about 0.1% (95%); zero in 31,576 Rule 110 calls (all v2 runs) bounds that
   rule below about 0.01%. These are upper bounds, not measurements. Jev's confidence never came near
   0.5 (every answer was >=0.96 or <=0.09), so errors, if they exist, are rare.
5. **The live 64-step ether run matches the reference exactly.** It is the same setup as
   the FakeJEV recording (which, at an injected 0.1% error rate, had 6 wrong updates
   and 34 diverged cells). The 200-step live run also matches exactly, and the site now
   plays it by default.

## Not shown

- Universality: a 200-step, 224-cell run is a demonstration only.
- An actual error rate (none observed), or whether errors are independent (needed
  before trusting triple voting).
- Robustness to wording. By choice, claims are stated for the exact wording used
  (quoted in the code README, "Exact wording used"); other phrasings were not tested.
